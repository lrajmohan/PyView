import neuroconnect as neu

a = neu.GiveTasteThread(0,0,1)
b = neu.GiveTasteThread(0,0,1,1)
